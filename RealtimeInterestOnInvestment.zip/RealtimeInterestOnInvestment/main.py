
import time

print(" Calculates real time interest earned for an investment".center(75,"~"))
try:
    timefile = open("time.txt","r")
    start_time = timefile.readline()
    #print(type(start_time))
    #print(type(time.time()))
    print(round(time.time()- float(start_time ),2))
    timefile.close()
    #where start_time is when investment account was opened and time.time() is the present real time
except:    
    file = open("time.txt","w")
    file.write(f"{time.time()}")
    file.close()
seconds = round(time.time()- float(start_time ),2)
print(f"It's been {seconds} seconds since investment account was opened.")  
#Calculating Annual interest at 2.3%
print(f"{time.ctime(time.time())}")
while True:
    year = 1_000_000 * 0.023
    month = year / 12
    week = month / 4
    day = week / 7
    hour = day / 24
    minute = hour / 60
    second = minute / 60
    time.sleep(2)
    print(f"""
          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          ___________________________USER DASHBOARD________________________________
          Date and time:              {time.ctime(time.time())}
          Investment account opened:  {round(time.time() - float(start_time),2)} seconds ago
          Interest gained/year:       ${round(year)}
          Interest gained/month:      ${round(month)}
          Interest gained/week:       ${round(week)}
          Interest gained/day:        ${round(day)}
          Interest gained/hour:       ${round(hour)}
          Interest gained/minute:     ${round(minute)}
          Interest gained/second:     ${round(second)}
          Opening balance: $1,000,000
          Current balance: ${1_000_000 + (round(second) * 0.023)} 
          """)






